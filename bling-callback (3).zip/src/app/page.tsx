export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>🧩 Bling Callback API</h1>
      <p>Rota <code>/api/bling-callback</code> ativa e funcionando.</p>
    </div>
  );
}
